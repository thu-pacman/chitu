__version__ = '2.6.0.post1'
git_version = 'ac3b116ce62d1219f933bc611acbde6f9887d0cb'
